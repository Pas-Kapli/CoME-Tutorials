from ete3 import Tree
from itertools import combinations
import sys

def read_groups(groups_filename,tree):
	groups = {}
	all_tips = [leaf.name for leaf in tree.iter_leaves()]
	with open(groups_filename, 'r') as file:
		for line in file:
			parts = line.strip().split()
			new_parts = []
			if len(parts) > 2:
				for i in parts[1:]:
					if i in all_tips: #keep only the samples that are in the tree
						new_parts.append(i)
				if len(new_parts)<2: #remove groups that have 1 or no samples
					continue
				else:
					groups[parts[0]] = set(new_parts)
	if groups == {}:
#		print("There are no groups left")
		sys.exit(0)
	else:
		return groups

def calculate_score(tree, groups):
	all_tips = [leaf.name for leaf in tree.iter_leaves()]
	total_score = 0
	perfect_groups=[]
	non_perfect_groups=[]
	for group in groups:
		samples = groups[group]
		group_score = 0
		for node in tree.traverse():
			leaves = set(node.get_leaf_names())
			if len(leaves) > 1: #if it is not a tip
				if leaves == samples:
					total_score+=1
					perfect_groups.append(group)
					break
	groups_all = list(groups.keys())
	non_perfect_groups = list(set(groups_all) - set(perfect_groups))
	
	intersection = []
	for group in non_perfect_groups:
		intersection_len = 0
		for node in tree.traverse():
			leaves = set(node.get_leaf_names())
			if len(all_tips) > len(leaves) > 1: #if it is not a tip and not the entire tree
				intersection = list(set(groups[group]) & set(leaves))
				if intersection_len < len(intersection):
					intersection_len = len(intersection)
					if set(leaves).issuperset(groups[group]):
						total_score+=len(groups[group])/len(leaves)
					if set(groups[group]).issuperset(leaves):
						total_score+= len(leaves)/len(groups[group])
				else:
					continue	
#	print(perfect_groups)
	return total_score / len(groups)

def main():
	newick_filename = sys.argv[1]
	groups_filename = sys.argv[2]

	tree = Tree(newick_filename)
	groups = read_groups(groups_filename, tree)
	score = calculate_score(tree, groups)
	print(sys.argv[1], "Total-score:", score)

if __name__ == "__main__":
	main()

