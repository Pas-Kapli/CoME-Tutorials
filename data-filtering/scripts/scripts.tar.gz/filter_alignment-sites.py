import sys

f = open(sys.argv[1], "r")
f1 = open(str(sys.argv[1]) + ".clean" + sys.argv[2], "w")

#########parse fasta#########
content = f.readlines()
new = [line.strip() for line in content]

count = 0
temp_seq = ''
taxa = []
seqs_original = []
for line in new:
    if '>' in line[0]:
        taxa.append(line)
        if count > 0:
            seqs_original.append(temp_seq)
            temp_seq = ''
    else:
        temp_seq += line
        count += 1
seqs_original.append(temp_seq)

#########filter sites#########

seqs_trans_orig = [''.join(s) for s in zip(*seqs_original)]

intab = "X"
outtab = "-"
trantab = str.maketrans(intab, outtab)

seqs_trans_new = []
for seq in seqs_trans_orig:
    tmp = seq.translate(trantab)
    if int(sys.argv[2]) == 0:
        if tmp.count("-") == len(taxa):
            continue
        else:
            seqs_trans_new.append(seq)
    else:
        if tmp.count("-") >= len(taxa) - int(sys.argv[2]):
            continue
        else:
            seqs_trans_new.append(seq)

seqs_clean = [''.join(s) for s in zip(*seqs_trans_new)]

for i in range(len(taxa)):
    f1.write(str(taxa[i]) + "\n")
    f1.write(str(seqs_clean[i]) + "\n")

print("The number of taxa in the alignment is: " + str(len(taxa)))
print("The original alignment_length is: " + str(len(seqs_original[0])))
print("The filtered alignment length is: " + str(len(seqs_clean[0])))

f.close()
f1.close()
