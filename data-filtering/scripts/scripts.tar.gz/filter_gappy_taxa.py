import sys

f = open(sys.argv[1], "r")
f1 = open(str(sys.argv[1])+".nogappy", "w")

#########parse fasta#########
content = f.readlines()
new=[]
for i in range(len(content)):
	new.append(content[i].strip())

count = 0
temp_seq=''
taxa = []
seqs_original = []
for i in range(len(new)):
	if '>' in new[i][0]:
		taxa.append(new[i])
		if count>0:
			seqs_original.append(temp_seq)
			temp_seq=''
	else:
		temp_seq=temp_seq + new[i]
		count = count +1
seqs_original.append(temp_seq)


for i in range(len(seqs_original)):
	gaps = seqs_original[i].count('-') + seqs_original[i].count('X')
	perc_gaps = float(gaps)/float(len(seqs_original[i]))
	if perc_gaps < float(sys.argv[2]):
		f1.write(taxa[i] + "\n")
		f1.write(seqs_original[i] + "\n")
	else:
		print(sys.argv[1],taxa[i],perc_gaps, "removed")

f1.close()
f.close()
